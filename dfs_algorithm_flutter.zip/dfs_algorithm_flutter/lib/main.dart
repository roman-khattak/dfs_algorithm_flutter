import 'package:dfs_algorithm_flutter/view/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: HomeScreen(),
    );
  }
}


// import 'dart:collection';
//
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// class SuggestFriendsDFS<T> {
//   final HashMap<T, List<T>> _adj = HashMap();
//   final List<Set<T>> groups = [];
//
//   void addFriendship(T src, T dest) {
//     _adj.putIfAbsent(src, () => <T>[]);
//     _adj[src]!.add(dest);
//     _adj.putIfAbsent(dest, () => <T>[]);
//     _adj[dest]!.add(src);
//   }
//
//   void findGroups() {
//     Map<T, bool> visited = HashMap();
//
//     for (T t in _adj.keys) {
//       visited[t] = false;
//     }
//
//     for (T t in _adj.keys) {
//       if (visited[t] == false) {
//         Set<T> group = HashSet();
//         _dfs(t, visited, group);
//         groups.add(group);
//       }
//     }
//   }
//
//   void _dfs(T v, Map<T, bool> visited, Set<T> group) {
//     visited[v] = true;
//     group.add(v);
//     for (T x in _adj[v] ?? []) {
//       if ((visited[x] ?? true) == false) _dfs(x, visited, group);
//     }
//   }
//
//   Set<T> getSuggestedFriends(T a) {
//     if (groups.isEmpty) findGroups();
//
//     var result = groups.firstWhere((element) => element.contains(a),
//         orElse: () => <T>{});
//
//     if (result.isNotEmpty) result.remove(a);
//
//     return result;
//   }
// }
//
// void main() {
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return GetMaterialApp(
//       home: HomeScreen(),
//     );
//   }
// }
//
// class HomeScreen extends StatelessWidget {
//   final SuggestFriendsDFS<String> friendSuggestions = SuggestFriendsDFS();
//
//   HomeScreen() {
//     // Add sample friend connections
//     friendSuggestions.addFriendship("Ashley", "Christopher");
//     friendSuggestions.addFriendship("Ashley", "Emily");
//     // Add more friendships here...
//
//     friendSuggestions.findGroups();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Friend Suggestions'),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: <Widget>[
//             Text(
//               'Friend Suggestions for:',
//             ),
//             FriendInput(friendSuggestions: friendSuggestions),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class FriendInput extends StatefulWidget {
//   final SuggestFriendsDFS<String> friendSuggestions;
//
//   FriendInput({required this.friendSuggestions});
//
//   @override
//   _FriendInputState createState() => _FriendInputState();
// }
//
// class _FriendInputState extends State<FriendInput> {
//   TextEditingController textController = TextEditingController();
//   String? friendName;
//   Set<String> suggestedFriends = {};
//
//   void updateSuggestions() {
//     setState(() {
//       friendName = textController.text;
//       if (friendName != null && friendName!.isNotEmpty) {
//         suggestedFriends = widget.friendSuggestions.getSuggestedFriends(friendName!);
//       } else {
//         suggestedFriends.clear();
//       }
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         TextField(
//           controller: textController,
//           decoration: InputDecoration(labelText: 'Enter your friend\'s name'),
//           onChanged: (_) => updateSuggestions(),
//         ),
//         SizedBox(height: 10),
//         Text('Suggestions for friends:'),
//         Text(suggestedFriends.join(', ')),
//       ],
//     );
//   }
// }
