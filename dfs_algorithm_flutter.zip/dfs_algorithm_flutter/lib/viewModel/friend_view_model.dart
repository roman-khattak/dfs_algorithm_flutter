import 'package:get/get.dart';

class FriendModel {
  final String name;
  final List<String> friends;

  FriendModel({required this.name, required this.friends});
}

class FriendViewModel extends GetxController {
  final List<FriendModel> _friends = <FriendModel>[].obs;

  List<FriendModel> get friends => _friends;

  void addFriendship(String src, String dest) {
    _friends.add(FriendModel(name: src, friends: [dest]));
    _friends.add(FriendModel(name: dest, friends: [src]));
  }

  void findGroups() {
    final Set<String> visited = <String>{};
    final List<Set<String>> groups = <Set<String>>[];

    for (final friend in _friends) {
      if (!visited.contains(friend.name)) {
        final group = <String>{};
        _dfs(friend.name, visited, group);
        groups.add(group);
      }
    }
    update();
  }

  void _dfs(String v, Set<String> visited, Set<String> group) {
    visited.add(v);
    group.add(v);

    final friends = _friends.firstWhere((friend) => friend.name == v).friends;
    for (final x in friends) {
      if (!visited.contains(x)) {
        _dfs(x, visited, group);
      }
    }
  }

  List<String> getSuggestedFriends(String a) {
    if (_friends.isEmpty) findGroups();

    final currentFriends = _friends.firstWhere(
          (friend) => friend.name == a,
      orElse: () => FriendModel(name: a, friends: []), // Provide a default value
    );

    if (currentFriends.friends.isEmpty) {
      return [];
    }

    final suggestedFriends = <String>{};

    for (final group in _friends) {
      if (group.name != a && !currentFriends.friends.contains(group.name)) {
        suggestedFriends.addAll(group.friends);
      }
    }

    return suggestedFriends.toList();
  }

}
