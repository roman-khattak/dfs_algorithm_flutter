import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../viewModel/friend_view_model.dart';

class FriendInput extends StatelessWidget {
  final FriendViewModel friendViewModel = Get.find<FriendViewModel>();
  final TextEditingController textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: textController,
          decoration: InputDecoration(labelText: 'Enter your friend\'s name'),
        ),
        ElevatedButton(
          onPressed: () {
            friendViewModel.update();
          },
          child: Text('Get Suggestions'),
        ),
        Obx(() {
          final friendName = textController.text;
          final suggestedFriends = friendViewModel.getSuggestedFriends(friendName);
          return Column(
            children: <Widget>[
              Text('Suggestions for friends:'),
              if (suggestedFriends.isNotEmpty) // Check if the list is not empty
                Text(suggestedFriends.join(', ')),
              if (suggestedFriends.isEmpty) // Optionally, display a message if the list is empty
                Text('No suggestions available'),
            ],
          );
        }),

      ],
    );
  }
}
