import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../viewModel/friend_view_model.dart';
import 'friend_input.dart';

class HomeScreen extends StatelessWidget {
  final FriendViewModel friendViewModel = Get.put(FriendViewModel());

  HomeScreen() {
    friendViewModel.addFriendship("Ashley", "Christopher");
    friendViewModel.addFriendship("Ashley", "Emily");
    // Add more friendships here...

    friendViewModel.findGroups();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Friend Suggestions'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Friend Suggestions for:',
            ),
            FriendInput(),
          ],
        ),
      ),
    );
  }
}
